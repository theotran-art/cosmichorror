branch = 'fix'
nightly = False
official = True
version = '8.5.2.26010301'
version_name = 'In Good Health'
